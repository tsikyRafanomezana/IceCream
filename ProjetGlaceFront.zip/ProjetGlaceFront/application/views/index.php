<html lang="zxx"><head>
	<title>Ice Cream Hotel Spécialités</title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8">
	<meta name="keywords" content="Ice Cream hotel,glace">
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--// Meta tag Keywords -->

	<!-- Custom-Files -->
	<link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.css");?>">
	<!-- Bootstrap-Core-CSS -->
	<link href="<?php echo base_url("assets/css/simpleLightbox.css");?>" rel="stylesheet" type="text/css">
	<!-- simpleLightbox css -->
	<link rel="stylesheet" href="<?php echo base_url("assets/css/style.css");?>" type="text/css" media="all">
	<!-- Style-CSS -->
	<link rel="stylesheet" href="<?php echo base_url("assets/css/fontawesome-all.css");?>">
        <link type="text/css" rel="stylesheet" href="<?php echo base_url("assets/css/cssSprite.css");?>" >
	<!-- Font-Awesome-Icons-CSS -->
	<!-- //Custom-Files -->

	<!-- Web-Fonts -->
	<link href="//fonts.googleapis.com/css?family=Pacifico&amp;subset=cyrillic,latin-ext,vietnamese" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Barlow+Semi+Condensed:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;subset=latin-ext" rel="stylesheet">
	<!-- //Web-Fonts -->

</head>

<body>
	<!-- header -->
	<div class="header">
		<!-- navigation -->
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
                        <span class="sprite logo_png"></span>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>

			
		</nav>
		<!-- //navigation -->
	</div>
	<!-- //header -->
	<!-- banner -->
	<div class="banner-2">

	</div>
	<!-- //banner -->

	<!-- gallery -->
	<section class="gallery py-5">
		<div class="container py-xl-5 py-lg-3">
                    <div class="title-heading text-center mb-sm-5 mb-4">
                        <h1 class="title text-capitalize text-dark">Nos spécialités</h1>
                    </div>
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <?php $i=0; 
                            foreach($listeParfum as $liste){
                        ?>
                            <li class="nav-item">
                                    <h2><a href="<?php echo site_url("ProduitController/listeProduitParfum/");?><?php echo $liste['NOMPARFUM'];?>" class="nav-link active" aria-selected="true"><?php echo $liste['NOMPARFUM'];?></a></h2>
                            </li>
                            <?php $i++; } ?>
                    </ul>
                    <div class="inner-sec pt-md-4">
                        <div class="row proj_gallery_grid">
                            <?php $i=0; 
                                foreach($listePr as $liste){
                            ?>
                                <div class="col-sm-4 section_1_gallery_grid">	
                                    <div class="section_1_gallery_grid1">
                                            <img src="<?php echo base_url("../images/");?><?php echo $liste['IMAGE'];?>" alt="<?php echo $liste['IMAGE'];?>" class="img-fluid">
                                            <div class="proj_gallery_grid1_pos">
                                                <h3><?php echo $liste['NOMPRODUIT'];?></h3>
                                                <h4 class="text-white text-capitalize mb-5"><?php echo $liste['PRIX'];?> Ar</h4>
                                            </div>
                                    </div>
                                </div>	
                            <?php $i++; } ?>
                        </div>				
                    </div>
		</div>
	</section>
	<!--//gallery-->

	<!-- stats -->
	
	<!-- //stats -->

	<!-- middle slider -->
	
	<!-- //middle slider -->

	<!-- newsletter -->
	
	<!-- //newsletter -->

	<!-- footer -->
	<div class="mkl_footer text-center py-4">
		<div class="container py-xl-5 py-4">
			<div class="mkls_footer_grid">
				<h5 class="text-white text-capitalize mb-5">we are best in making ice creams</h5>
				
				<!-- footer logo -->
				<div class="logo2 my-sm-5 my-4">					
                                    <span class="sprite logo_png"></span>	
				</div>
				<!-- //footer logo -->
			</div>
			<!-- address -->
			<div class="contact-left-footer border-bottom pb-sm-5 pb-4">
				<ul>
					<li>
						<p class="text-white">
							<i class="fas fa-location-arrow mr-2"></i>19Ter Mahazo, Tananarive</p>
					</li>
					<li class="mx-4">
						<p class="text-white">
							<i class="fas fa-phone mr-2"></i>+261 34 06 428 04.</p>
					</li>
					<li>
						<p class="text-white">
							<i class="far fa-envelope-open mr-2"></i>
							<a href="#" class="text-white">iceCream@gmail.com</a>
						</p>
					</li>
				</ul>
			</div>
			<!-- //address -->
		</div>
	</div>
	<!-- //footer -->

	<!-- copyright -->
	<div class="w3l-copy text-center py-4">
		<p class="text-white">Miniprojet web design S6</p>
                <p class="text-white">RAFANOMEZANA Tahiry Bakolitsiky</p>
                <p class="text-white">ETU681-P10B</p>
	</div>
	<!-- //copyright -->


	<!-- Js files -->

	<!-- JavaScript -->
	<script src="<?php echo base_url("assets/js/jquery-2.2.3.min.js");?>"></script>
	<!-- Default-JavaScript-File -->

	<!-- simpleLightbox -->
	<script src="<?php echo base_url("assets/js/simpleLightbox.js");?>"></script>
	<script>
		$('.proj_gallery_grid a').simpleLightbox();
	</script>
	<!-- //simpleLightbox -->

	<!-- flexisel slider (for middle Slider) -->
	<script src="<?php echo base_url("assets/js/jquery.flexisel.js");?>"></script>
	<script>
		$(window).load(function () {
			$("#flexiselDemo1").flexisel({
				visibleItems: 5,
				animationSpeed: 1000,
				autoPlay: true,
				autoPlaySpeed: 3000,
				pauseOnHover: true,
				enableResponsiveBreakpoints: true,
				responsiveBreakpoints: {
					portrait: {
						changePoint: 480,
						visibleItems: 2
					},
					landscape: {
						changePoint: 640,
						visibleItems: 3
					},
					tablet: {
						changePoint: 768,
						visibleItems: 4
					}
				}
			});

		});
	</script>
	<!-- //flexisel slider (for middle Slider) -->

	<!-- stats -->
	<script src="<?php echo base_url("assets/js/jquery.waypoints.min.js");?>"></script>
	<script src="<?php echo base_url("assets/js/jquery.countup.js");?>"></script>
	<script>
		$('.counter').countUp();
	</script>
	<!-- //stats -->

	<!-- smooth scrolling -->
	<script src="<?php echo base_url("assets/js/SmoothScroll.min.js");?>"></script>
	<!-- //smooth scrolling -->

	<!-- start-smoth-scrolling -->
	<script src="<?php echo base_url("assets/js/move-top.js");?>"></script>
	<script src="<?php echo base_url("assets/js/easing.js");?>"></script>
	<script>
		jQuery(document).ready(function ($) {
			$(".scroll").click(function (event) {
				event.preventDefault();
				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 1000);
			});
		});
	</script>
	<!-- start-smoth-scrolling -->

	<!-- smooth scrolling-bottom-to-top -->
	<script>
		$(document).ready(function () {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
			$().UItoTop({
				easingType: 'easeOutQuart'
			});
		});
	</script>
	<!-- //smooth scrolling-bottom-to-top -->

	<script src="<?php echo base_url("assets/js/bootstrap.js");?>"></script>
	<!-- Necessary-JavaScript-File-For-Bootstrap -->

	<!-- //Js files -->



<a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 0;"></span>To Top</a></body></html>