<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
    defined('BASEPATH') OR exit('No direct script access allowed');
	
    class IndexModele extends CI_Model{
        public function getIdParfum($nom){
            $query = $this->db->query("SELECT IDPARFUM
                                FROM PARFUM WHERE NOMPARFUM ='".$nom."'");
            $data = 0;
            foreach ($query->result_array() as $row) {
                $data = $row['IDPARFUM'];
            }
            $this->db->close();
            return $data;
        }
        public function listerParfum(){
            $query = $this->db->query('SELECT NOMPARFUM
                                FROM PARFUM');
            $data = array();
            $i = 0;
            foreach ($query->result_array() as $row) {
                $data[$i]['NOMPARFUM'] = $row['NOMPARFUM'];
                $i++;
            }
            $this->db->close();
            return $data;
        }
        public function listeProduitParfum($id){
            $query = $this->db->query("SELECT *
                                FROM PRODUIT WHERE IDPARFUM ='".$id."'");
            $i = 0;
            $data = array();
            foreach ($query->result_array() as $row) {
                $data[$i]['IDPRODUIT'] = $row['IDPRODUIT'];
                $data[$i]['IDADMIN'] = $row['IDADMIN'];
                $data[$i]['IDPARFUM'] = $row['IDPARFUM'];
                $data[$i]['NOMPRODUIT'] = $row['NOMPRODUIT'];
                $data[$i]['PRIX'] = $row['PRIX'];
                $data[$i]['IMAGE'] = $row['IMAGE'];
                $i++;
            }
            return $data;
            $this->db->close();
            
        }
    }
?>
