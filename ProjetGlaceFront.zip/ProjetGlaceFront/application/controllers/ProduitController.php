<?php
class ProduitController extends CI_Controller {
    public function listeProduitParfum($nomParfum){
        $this->load->model('IndexModele');
        $idParfum = $this->IndexModele->getIdParfum($nomParfum);
        var_dump($idParfum);
        $data['listePr'] = $this->IndexModele->listeProduitParfum($idParfum);
        $data['listeParfum'] = $this->IndexModele->listerParfum();
        //if($data!=NULL){
            $this->load->view('index_front',$data);
        //}
        /*else echo "<center> <div class=\"alert alert-danger\" style=\"font-size: 24px;\"> <strong>Erreur: </strong>Aucun produit:( </div> </center> ";
             $this->load->view('index_front');*/
    }
}
?>

