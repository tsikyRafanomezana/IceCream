drop table if exists ADMIN;

drop table if exists PARFUM;

drop table if exists PRODUIT;

/*==============================================================*/
/* Table: ADMIN                                                 */
/*==============================================================*/
create table ADMIN
(
   IDADMIN              int not null auto_increment,
   NOMADMIN             varchar(100),
   MDP                  varchar(50),
   primary key (IDADMIN)
);

/*==============================================================*/
/* Table: PARFUM                                                */
/*==============================================================*/
create table PARFUM
(
   IDPARFUM             int not null auto_increment,
   NOMPARFUM            varchar(100),
   primary key (IDPARFUM)
);

/*==============================================================*/
/* Table: PRODUIT                                               */
/*==============================================================*/
create table PRODUIT
(
   IDPRODUIT            int not null auto_increment,
   IDADMIN              int not null,
   IDPARFUM             int not null,
   NOMPRODUIT           varchar(100),
   PRIX                 decimal(18,2),
   IMAGE                varchar(100),
   primary key (IDPRODUIT)
);

alter table PRODUIT add constraint FK_ASSOCIATION_1 foreign key (IDPARFUM)
      references PARFUM (IDPARFUM) on delete restrict on update restrict;

alter table PRODUIT add constraint FK_ASSOCIATION_2 foreign key (IDADMIN)
      references ADMIN (IDADMIN) on delete restrict on update restrict;
	  
insert into PARFUM VALUES(NULL,'Chocolat');
insert into ADMIN VALUES(NULL,'Tsiky','060019800ff9b672b7a37f93d22c4f55118f964b');

select count(*) from ADMIN where nomAdmin='Tsiky' and mdp='060019800ff9b672b7a37f93d22c4f55118f964b'