<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="<?php echo base_url("assets/css/bootstrap.min.css");?>" rel='stylesheet' type='text/css' />
<!--<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />-->
<!-- Custom Theme files -->
<link href="<?php echo base_url("assets/css/style.css");?>" rel='stylesheet' type='text/css' />
<link href="<?php echo base_url("assets/css/font-awesome.css");?>" rel="stylesheet"> 
<script src="<?php echo base_url("assets/jquery.min.js");?>"> </script>
<script src="<?php echo base_url("assets/bootstrap.min.js");?>"> </script>
  
<!-- Mainly scripts -->
<script src="<?php echo base_url("assets/jquery.metisMenu.js");?>"></script>
<script src="<?php echo base_url("assets/jquery.slimscroll.min.js");?>"></script>
<!-- Custom and plugin javascript -->
<link href="<?php echo base_url("assets/css/custom.css");?>" rel="stylesheet">
<script src="<?php echo base_url("assets/custom.js");?>"></script>
<script src="<?php echo base_url("assets/screenfull.js");?>"></script>
<script>
$(function () {
        $('#supported').text('Supported/allowed: ' + !!screenfull.enabled);

        if (!screenfull.enabled) {
                return false;
        }



        $('#toggle').click(function () {
                screenfull.toggle($('#container')[0]);
        });



});
</script>
