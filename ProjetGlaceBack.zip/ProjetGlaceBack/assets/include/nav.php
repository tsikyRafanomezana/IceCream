<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<nav class="navbar-default navbar-static-top" role="navigation">
    <div class="navbar-header">
       <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
           <span class="sr-only">Toggle navigation</span>
           <span class="icon-bar"></span>
           <span class="icon-bar"></span>
           <span class="icon-bar"></span>
       </button>
      <h1> <a class="navbar-brand" href="#">Ice Cream</a></h1>         
                  </div>
                <div class=" border-bottom">
               <div class="clearfix"></div>

       <div class="navbar-default sidebar" role="navigation">
           <div class="sidebar-nav navbar-collapse">
               <ul class="nav" id="side-menu">
                   <li>
                       <a href="#" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Dashboards</span> </a>
                   </li>
                   <li>
                       <a href="<?php echo site_url("adminController/index");?>" class=" hvr-bounce-to-right"><i class="fa fa-list nav_icon"></i> <span class="nav-label">Produit</span></a>
                       <a href="<?php echo site_url("parfumController/formulaire");?>" class=" hvr-bounce-to-right"><i class="fa fa-align-left nav_icon"></i>Parfum</a>  
                       <a href="<?php echo site_url("adminController/deconnexion");?>" class=" hvr-bounce-to-right"><i class="fa fa-align-left nav_icon"></i>Deconnexion</a>
                   </li>
               </ul>
           </div>
       </div>
</nav>
