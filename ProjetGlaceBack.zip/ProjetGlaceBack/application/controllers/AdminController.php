<?php 
	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class AdminController extends CI_Controller {
		public function __construct()
        {
                parent::__construct();
                
        }
		public function index(){
                    $this->load->model('ParfumModele');
                    $data['parfum'] = $this->ParfumModele->listerParfum();
                    $this->load->view('bienvenu',$data);
		}
		public function testerLogin(){
                    $nom = $this->input->post('nom');
                    $mdp = $this->input->post('mdp');
			/*var_dump($nom);
			var_dump($mdp);*/
                    $this->load->model('AdminModele');
                    $data['admin'] = $this->AdminModele->connexion($nom,$mdp);
                    $this->load->model('ParfumModele');
                    $data['parfum'] = $this->ParfumModele->listerParfum();
                    $this->load->model('ProduitModele');
                    $data['listeProduit'] =  $this->ProduitModele->listerProduit();
                    if( $data['admin']['nb'] == 1){
                        $this->session->set_userdata('idAdmin',$data['admin']['id']);
                        $this->load->view('listeProduit',$data);
                    }
                    else{
                        echo "<center> <div class=\"alert alert-danger\" style=\"font-size: 24px;\"> <strong>Erreur: </strong> mot de passe ou utilisateur admin incorrect :( </div> </center> ";
                        $this->load->view('index',$data);
                    }
		}
		public function deconnexion(){
			$this->session->sess_destroy();
			$this->load->view('index');
		}
	}
?>