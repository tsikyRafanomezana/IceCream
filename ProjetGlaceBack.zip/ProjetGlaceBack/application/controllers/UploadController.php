<?php

        class UploadController extends CI_Controller {

        public function __construct()
        {
            parent::__construct();
        }

        public function index()
        {
                $this->load->view('upload_form', array('error' => ' ' ));
        }

        public function do_upload()
        {
            $config['upload_path']          = '../images';
            $config['allowed_types']        = 'gif|jpg|png|jpeg';
            $config['max_size']             = 100000;
            $config['max_width']            = 1500;
            $config['max_height']           = 1500;

            $this->load->library('upload', $config);

            if ( ! $this->upload->do_upload('userfile'))
            {
                    $error['erreur'] = array('error' => $this->upload->display_errors());
                    echo "<center> <div class=\"alert alert-danger\" style=\"font-size: 24px;\"> <strong>Erreur: </strong>Erreur fichier:( </div> </center> ";
                    $this->load->model('ParfumModele');
                    $error['parfum'] = $this->ParfumModele->listerParfum();  
                    $this->load->view('bienvenu', $error);
            }
            else
            {
                    $data = array('upload_data' => $this->upload->data());

                    //$this->load->view('Upload_success', $data);
                    $pr     = $this->input->post('produit');
                    $prix   = $this->input->post('prix');
                    $parfum = $this->input->post('parfum');
                    $image  = basename($_FILES['userfile']['name']); 
                    $idAdmin = $this->session->userdata('idAdmin');
                    /*var_dump($pr);
                    var_dump($prix);
                    var_dump($parfum);
                    var_dump($image);
                    var_dump($idAdmin);*/
                    $this->load->model('ParfumModele');
                    $idParfum = $this->ParfumModele->getIdParfum($parfum);
                    $this->load->model('ProduitModele');
                    $this->load->model('ParfumModele');
                    $data['parfum'] = $this->ParfumModele->listerParfum();  
                    $data['listeProduit'] = $this->ProduitModele->listerProduit();
                    if($idAdmin!=0 && $idParfum!=0 && $pr!=NULL && $prix!=0 && $image!=NULL){
                        $this->ProduitModele->insertion($idAdmin,$idParfum,$pr,$prix,$image);
                        $this->load->view('listeProduit',$data);
                    }
                    else
                        echo "<center> <div class=\"alert alert-danger\"style=\"font-size: 24px;\"> <strong>Erreur: </strong>Donnée invalide:( </div> </center> ";
                        $this->load->model('ParfumModele');
                        $data['parfum'] = $this->ParfumModele->listerParfum();  
                        $this->load->view('bienvenu',$data);
            }
        }
    }
?>