<?php 
    defined('BASEPATH') OR exit('No direct script access allowed');

    class ParfumController extends CI_Controller {
        public function formulaire(){	
            $this->load->view('ajoutParfum');
        }
        public function ajoutParfum(){
            $nom = $this->input->get('nouveauParfum');
            $this->load->model('ParfumModele');
            $this->ParfumModele->insertion($nom);
            $this->load->view('ajoutParfum');
        }
    }
?>