<?php 
    defined('BASEPATH') OR exit('No direct script access allowed');

    class ProduitController extends CI_Controller{
        public function inserer(){
            $this->load->model('ParfumModele');
            $data['parfum'] = $this->ParfumModele->listerParfum();
            $this->load->view('bienvenu',$data);
        }
        /*public function listerProduit(){
            $this->load->model('ProduitModele');
            $data['listeProduit'] = $this->ParfumModele->listerProduit();
            
        }*/
        public function supprimer($idSuppr){
            //$id = $this->uri->segment($idSuppr);
            var_dump($idSuppr);
            $this->load->model('ProduitModele');
            $this->ProduitModele->supprimer($idSuppr);
            $data['listeProduit'] = $this->ProduitModele->listerProduit();
            $this->load->view('listeProduit',$data);
        }
    }
?>