<html style="overflow: hidden;"><head>
    <title>Ajout Parfum</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="chocolat" />
    <?php include("assets/include/head.php"); ?> 
</head>
<body>
<div id="wrapper">
     <!----->
        <?php include("assets/include/nav.php"); ?> 
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 	<!--grid-->
 	<div class="grid-form">
 		
<!----->

<!---->

<!---->



<!---->
	<div class="grid-form1">
	<h3 id="forms-horizontal">Insertion nouveau parfum</h3>
	<form class="form-horizontal" action="<?php echo site_url("parfumController/ajoutParfum");?>" method="GET">
	  <div class="form-group">
		<label for="parfum" class="col-sm-2 control-label hor-form">Parfum</label>
		<div class="col-sm-10">
		  <input type="text" class="form-control" name="nouveauParfum" placeholder="Chocolat">
		</div>
	  </div>
	  <div class="form-group">
		<div class="col-sm-offset-2 col-sm-10">
		  <button type="submit" class="btn btn-default">Insérer</button>
		</div>
	  </div>
	</form>
	</div>
 	<!--//grid-->
		<!---->
		</div>
                <div class="copy"> 
                       <p>Miniprojet web design S6</p>
                       <p>RAFANOMEZANA Tahiry Bakolitsiky</p>
                       <p>ETU681-P10B</p>
                   </div>
		</div>
		<div class="clearfix"> </div>
       </div>
     <!--scrolling js-->
	<script src="<?php echo base_url("assets/jquery.nicescroll.js");?>"></script>
	<script src="<?php echo base_url("assets/scripts.js");?>"></script><div id="ascrail2000" class="nicescroll-rails" style="width: 6px; z-index: 1000; background: rgb(66, 79, 99); cursor: default; position: fixed; top: 0px; height: 100%; right: 0px; opacity: 0;"><div style="position: relative; top: 423px; float: right; width: 6px; height: 87px; background-color: rgb(26, 188, 156); border: 0px; background-clip: padding-box; border-radius: 10px;"></div></div><div id="ascrail2000-hr" class="nicescroll-rails" style="height: 6px; z-index: 1000; background: rgb(66, 79, 99); position: fixed; left: 0px; width: 100%; bottom: 0px; cursor: default; display: none; opacity: 0;"><div style="position: relative; top: 0px; height: 6px; width: 1366px; background-color: rgb(26, 188, 156); border: 0px; background-clip: padding-box; border-radius: 10px;"></div></div>
	<!--//scrolling js-->
<!---->




</body>
</html>