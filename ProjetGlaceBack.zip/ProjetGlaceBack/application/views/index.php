<html style="overflow: hidden;">
<head>
    <title>Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="keywords" content="Minimal Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
    Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design">
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <!-- Custom Theme files -->
    <link href=<?php echo base_url("assets/css/style.css");?> rel="stylesheet" type="text/css">
    <link href=<?php echo base_url("assets/css/font-awesome.css");?> rel="stylesheet"> 
    <script src=<?php echo base_url("assets/js/jquery.min.js");?>> </script>
    <script src=<?php echo base_url("assets/js/bootstrap.min.js");?>> </script>
</head>
<body>
	<div class="login">
		<h1>Connexion</h1>
		<div class="login-bottom">
                    <h2>Login</h2>
			<form action="<?php echo site_url("adminController/testerLogin"); ?>" method="POST">
			<div class="col-md-6">
				<div class="login-mail">
                                    <input type="text" placeholder="Entrer votre nom" name="nom" required="">
				</div>
				<div class="login-mail">
                                    <input type="password" placeholder="Entrer votre mot de passe" name="mdp" required="" value="tsiky">
				</div>
				<div class="col-md-6 login-do">
					<label class="hvr-shutter-in-horizontal login-sub">
					<input type="submit" value="login">
					</label>
				</div>
			</div>
			<div class="clearfix"> </div>
			</form>
		</div>
	</div>
		<!---->
<div class="copy-right">
            <p>Ice cream</p></div>  
<!---->
<!--scrolling js-->
	<script src=<?php echo base_url("assets/js/jquery.nicescroll.js");?>></script>
	<script src=<?php echo base_url("assets/js/scripts.js");?>></script><div id="ascrail2000" class="nicescroll-rails" style="width: 6px; z-index: 1000; background: rgb(66, 79, 99); cursor: default; position: fixed; top: 0px; height: 100%; right: 0px; opacity: 0; display: block;"><div style="position: relative; top: 0px; float: right; width: 6px; height: 156px; background-color: rgb(26, 188, 156); border: 0px; background-clip: padding-box; border-radius: 10px;"></div></div><div id="ascrail2000-hr" class="nicescroll-rails" style="height: 6px; z-index: 1000; background: rgb(66, 79, 99); position: fixed; left: 0px; width: 100%; bottom: 0px; cursor: default; display: none; opacity: 0;"><div style="position: relative; top: 0px; height: 6px; width: 1366px; background-color: rgb(26, 188, 156); border: 0px; background-clip: padding-box; border-radius: 10px;"></div></div>
	<!--//scrolling js-->



</body></html>