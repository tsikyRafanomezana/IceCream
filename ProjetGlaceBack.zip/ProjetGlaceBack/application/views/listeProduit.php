<!DOCTYPE HTML>
<html>
<head>
    <title>Liste Produit</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="ice cream,parfum,dessert" />
    <?php include("assets/include/head.php"); ?> 
</head>
<body>
<div id="wrapper">
        <!----->
        <?php include("assets/include/nav.php"); ?> 
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
		<div class="banner">
			<h2>Home
			<i class="fa fa-angle-right"></i>
			<span>Liste Produit</span>			
			</h2>
			<a href="<?php echo site_url("produitController/inserer");?>">Ajouter</a>
		</div>
 	 <!--gallery-->
 	 <div class="gallery">
            <?php 
                $i = 0;
                foreach ($listeProduit as $liste){
            ?>
                <div class="col-md">
                    <div class="gallery-img">
                        <img class="img-responsive " src="<?php echo base_url("../images");?>/<?php echo $liste['IMAGE'];?>" alt="<?php echo $liste['IMAGE'];?>" />   
                               <span class="zoom-icon"> </span> </a>
                    </div>	
                    <div class="text-gallery">
                        <center>
                            <h3><?php echo $liste['NOMPRODUIT'];?></h3>
                            <h4><?php echo $liste['PRIX'];?></h4>
                        </center>
                    </div>
                    </br>
                    <div class="">
                        <center>
                            <a href="<?php echo site_url("produitController/supprimer");?>/<?php echo $liste['IDPRODUIT'];?>">Supprimer</a>                            
                        </center> 
                    </div>
 	 	</div>
                <?php $i++; } ?>
            <div class="clearfix"></div>
 	</div>
	<!--//gallery-->
		<!---->
            <div class="copy"> 
                <p>Miniprojet web design S6</p>
                <p>RAFANOMEZANA Tahiry Bakolitsiky</p>
                <p>ETU681-P10B</p>
            </div>
        </div>
        </div>
        <div class="clearfix"> </div>
       </div>
     
<!---->
<link rel="stylesheet" href="css/swipebox.css">
	<script src="js/jquery.swipebox.min.js"></script> 
	    <script type="text/javascript">
			jQuery(function($) {
				$(".swipebox").swipebox();
			});
</script>
<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->

</body>
</html>

