<?php 
	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class AdminModele extends CI_Model{
		public function connexion($nom,$mdp){
			$motDePasse = sha1($mdp);
			//var_dump($motDePasse);
            $query = $this->db->query("SELECT COUNT(*) nb, idAdmin
                                        FROM ADMIN
                                        WHERE NOMADMIN = '".$nom."' AND MDP = '".$motDePasse."'");
            $data = array();
            foreach ($query->result_array() as $row) {
                $data['nb'] = $row['nb'];
                $data['id'] = $row['idAdmin'];
            }
            $this->db->close();
            return $data;
        }
	}
?>