<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
    class ProduitModele extends CI_Model{
        public function insertion($idAdmin,$idParfum,$produit,$prix,$image){
           $this->db->query("INSERT INTO PRODUIT VALUES(NULL,'".$idAdmin."','".$idParfum."','".$produit."',".$prix.",'".$image."')");
        }
        public function listerProduit(){
            $query = $this->db->query('SELECT *
                                FROM PRODUIT');
            $data = array();
            $i = 0;
            foreach ($query->result_array() as $row) {
                $data[$i]['IDPRODUIT'] = $row['IDPRODUIT'];
                $data[$i]['IDADMIN'] = $row['IDADMIN'];
                $data[$i]['IDPARFUM'] = $row['IDPARFUM'];
                $data[$i]['NOMPRODUIT'] = $row['NOMPRODUIT'];
                $data[$i]['PRIX'] = $row['PRIX'];
                $data[$i]['IMAGE'] = $row['IMAGE'];
                $i++;
            }
            $this->db->close();
            return $data;
        }
        public function supprimer($idSuprr){
            $this->db->query("DELETE FROM PRODUIT WHERE IDPRODUIT='".$idSuprr."'");
        }
    }   
?>
