<?php 
    defined('BASEPATH') OR exit('No direct script access allowed');

    class ParfumModele extends CI_Model{
        public function getIdParfum($nom){
            $query = $this->db->query("SELECT IDPARFUM
                                FROM PARFUM WHERE NOMPARFUM ='".$nom."'");
            $data = 0;
            foreach ($query->result_array() as $row) {
                $data = $row['IDPARFUM'];
            }
            $this->db->close();
            return $data;
        }
        public function listerParfum(){
            $query = $this->db->query('SELECT NOMPARFUM
                                FROM PARFUM');
            $data = array();
            $i = 0;
            foreach ($query->result_array() as $row) {
                $data[$i]['NOMPARFUM'] = $row['NOMPARFUM'];
                $i++;
            }
            $this->db->close();
            return $data;
        }
        public function insertion($nom =''){
            $this->db->set('idParfum',NULL);
            $this->db->set('nomParfum',$nom);
            return $this->db->insert('PARFUM');
        }
    }
?>